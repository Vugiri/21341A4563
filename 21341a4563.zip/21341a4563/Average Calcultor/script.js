const numbersInput = document.getElementById('numbers-input');
const calculateBtn = document.getElementById('calculate-btn');
const primeNumbersElement = document.getElementById('prime-numbers');
const fibonacciNumbersElement = document.getElementById('fibonacci-numbers');
const evenNumbersElement = document.getElementById('even-numbers');
const randomNumbersElement = document.getElementById('random-numbers');
const averageElement = document.getElementById('average');

calculateBtn.addEventListener('click', () => {
  const numbers = numbersInput.value.split(',').map(Number);
  const primeNumbers = getPrimeNumbers(numbers);
  const fibonacciNumbers = getFibonacciNumbers(numbers);
  const evenNumbers = getEvenNumbers(numbers);
  const randomNumbers = getRandomNumbers(numbers);
  const allNumbers = [...primeNumbers, ...fibonacciNumbers, ...evenNumbers, ...randomNumbers];
  const average = calculateAverage(allNumbers);

  primeNumbersElement.textContent = `Prime numbers: ${primeNumbers.join(', ')}`;
  fibonacciNumbersElement.textContent = `Fibonacci numbers: ${fibonacciNumbers.join(', ')}`;
  evenNumbersElement.textContent = `Even numbers: ${evenNumbers.join(', ')}`;
  randomNumbersElement.textContent = `Random numbers: ${randomNumbers.join(', ')}`;
  averageElement.textContent = `Average: ${average.toFixed(2)}`;
});

function getPrimeNumbers(numbers) {
  return numbers.filter(isPrime);
}

function getFibonacciNumbers(numbers) {
  return numbers.filter(isFibonacci);
}

function getEvenNumbers(numbers) {
  return numbers.filter(isEven);
}

function getRandomNumbers(numbers) {
  return numbers.filter(() => Math.random() < 0.5);
}

function isPrime(n) {
  if (n <= 1) return false;
  for (let i = 2; i * i <= n; i++) {
    if (n % i === 0) return false;
  }
  return true;
}

function isFibonacci(n) {
  let a = 0;
  let b = 1;
  while (b < n) {
    let temp = a;
    a = b;
    b = temp + b;
  }
  return b === n;
}

function isEven(n) {
  return n % 2 === 0;
}

function calculateAverage(numbers) {
  return numbers.reduce((sum, current) => sum + current, 0) / numbers.length;
}