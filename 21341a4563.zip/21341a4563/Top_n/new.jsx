import React, { useState, useEffect } from 'react';

const api = {
  products: [
    { id: 1, name: 'Product 1', price: 100, rating: 4, availability: 'In Stock' },
    { id: 2, name: 'Product 2', price: 200, rating: 3, availability: 'Out of Stock' },
    { id: 3, name: 'Product 3', price: 300, rating: 5, availability: 'In Stock' },
  ],

  fetchProducts() {
    return Promise.resolve(this.products);
  },
};

const App = () => {
  const [products, setProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  useEffect(() => {
    api.fetchProducts().then(data => setProducts(data));
  }, []);

  const filteredProducts = products.filter(product => {
    return product.name.toLowerCase().includes(searchTerm.toLowerCase());
  });

  const handleSearchChange = event => {
    setSearchTerm(event.target.value);
  };

  const handlePageChange = event => {
    setPageNumber(event.target.value);
  };

  return (
    <div>
      <h1>All Products</h1>
      <form>
        <label>
          Search:
          <input type="text" value={searchTerm} onChange={handleSearchChange} />
        </label>
      </form>
      <table>
        <thead>
          <tr>
            <th>Product Name</th>
            <th>Price</th>
            <th>Rating</th>
            <th>Availability</th>
          </tr>
        </thead>
        <tbody>
          {filteredProducts.slice((pageNumber - 1) * pageSize, pageNumber * pageSize).map(product => (
            <tr key={product.id}>
              <td>{product.name}</td>
              <td>{product.price}</td>
              <td>{product.rating}</td>
              <td>{product.availability}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div>
        <label>
          Page:
          <select value={pageNumber} onChange={handlePageChange}>
            {Array(Math.ceil(filteredProducts.length / pageSize))
              .fill(0)
              .map((_, index) => (
                <option key={index + 1} value={index + 1}>
                  {index + 1}
                </option>
              ))}
          </select>
        </label>
      </div>
    </div>
  );
};

export default App;